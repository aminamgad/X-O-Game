let title = document.querySelector('.title')
let turn = 'x';
let squares =[];
let scoreX =document.querySelector(".scoreX");
let scoreO =document.querySelector(".scoreO");
let square =document.querySelector('.square');


/*
function scoreXX() {
    if (square.innerHTML==='x'
    ) {
console.log("Done");
        let counts=setInterval(updated);
        let upto=0;
        function updated(){
            var count= document.getElementById("scoreX");
            count.innerHTML=upto+1;

        }
        setInterval(function(){title.innerHTML += '.'},
        1000);
        setTimeout(function(){location.reload()},3000)
                if(upto>=1000)
            {
                clearInterval(counts);
            }

/*for (let i = 0; i < 10; i++) {
  scoreX=  scoreX.innerHTML + i ;

}*/
/*
    }};
    function scoreOO() {
        if (square.innerHTML==='o'
        &&square.innerHTML==='o'&&square.innerHTML==='o' ) {
    console.log("Done");
            let counts=setInterval(updated);
            let upto=0;
            function updated(){
                var count= document.getElementById("scoreO");
                count.innerHTML=upto+1;
    
            }
            setInterval(function(){title.innerHTML += '.'},
            1000);
            setTimeout(function(){location.reload()},3000)
                    if(upto>=1000)
                {
                    clearInterval(counts);
                }
    
    }};
    */
        
function theEnd() {
    title.innerHTML ='NO Winner';
    setInterval(function(){title.innerHTML += '.'},1000);
    setTimeout(function(){location.reload()},3000);    
}
//function clear_inputs(){
  //  inputs=document.getElementsByClassName('game')
    //for(input of inputs){
    //	input.value=' ' ///this emptys the inputs
    //}
  //}
function reload(){
   /*var set = new Set();
  var game= document.getElementsByClassName(".game");
  set.add(`${game}`);
   set.clear();*/
  setTimeout(function(){location.reload()},1000);    
}/*
function scoreee(n1,n2,n3) {
    square.innerHTML=`${squares[n1]} `;
    document.getElementById('square'+n1);
    document.getElementById('square'+n2);
    document.getElementById('square'+n3);

    for (let i = 1; i < 10; i++) {
        square[i] =  document.getElementById("square" +i)
        .innerHTML;
         }
     
}*/
function end(num1,num2,num3) {
    title.innerHTML=`${squares[num1]} Winner`;
    document.getElementById('item'+num1)
    .style.background ='black';
    document.getElementById('item'+num2)
    .style.background ='black';
    document.getElementById('item'+num3)
    .style.background ='black';
  //  scoreX.innerHTML+=1;
  if (squares[num1]==='x') {
    

  let counts=setInterval(updated);
  let upto=0;
  function updated(){
      var count= document.getElementById("scoreX");
      count.innerHTML=upto+1;
  }  }
  else if (squares[num1]==='o') {
    let counts=setInterval(updated);
    let upto=0;
    function updated(){
        var count= document.getElementById("scoreO");
        count.innerHTML=upto+1;
    } 
  }

    setInterval(function(){title.innerHTML += '.'},
    1000);
   setTimeout(function(){location.reload()},3000)

      upto=upto+1;
//let lastname = localStorage.setItem("upto")
//window.localStorage.setItem('name', 'Obaseki Nosa');

//const person = {
   // name:"Amin Amgad",
    //loaction:"egypt",
//}
//window.localStorage.setItem('user',JSON.
////stringify(person));
//window.localStorage.getItem('user');
//JSON.parse(window.localStorage.getItem('user'));
//JSON.stringify();
   // window.localStorage.setItem( "upto",1);
    //window.localStorage.getItem("upto");

}

//console.log(window.localStorage);
/*
function scoreXX(){
    for (let i = 1; i < 10; i++) {
        squares[i] =  document.getElementById("item" +i)
        .innerHTML;
         }     
         if(squares[1] == squares[2]
            && squares[2] == squares[3]
             && squares[1] === 'x'){
                let x = 0;
              x=  x+1;
           scoreX.innerHTML= x;
               
       }
    
}*/
let Game1 = document.querySelector('#item1');
let Game2 = document.querySelector('#item2');
let Game3 = document.querySelector('#item3');
let Game4 = document.querySelector('#item4');
let Game5 = document.querySelector('#item5');
let Game6 = document.querySelector('#item6');
let Game7 = document.querySelector('#item7');
let Game8 = document.querySelector('#item8');
let Game9 = document.querySelector('#item9');
function del(){
    Game1.innerHTML=square;
    Game2.innerHTML=square;
    Game3.innerHTML=square;
    Game4.innerHTML=square;
    Game5.innerHTML=square;
    Game6.innerHTML=square;
    Game7.innerHTML=square;
    Game8.innerHTML=square;
    Game9.innerHTML=square;
}
function winner() {
    for (let i = 1; i < 10; i++) {
   squares[i] =  document.getElementById("item" +i)
   .innerHTML;
    }
    if(squares[1] == squares[2]
        && squares[2] == squares[3]
         && squares[1] != ''){
         

           end(1,2,3); 
     }
  else if(squares[4] == squares[5]
    && squares[5] == squares[6]
     && squares[6] != ''){

        end(4,5,6);
    }
else if(squares[7] == squares[8]
    && squares[8] == squares[9]
     && squares[9] != ''){

        end(7,8,9);
    }
else if(squares[3] == squares[5]
    && squares[5] == squares[7]
     && squares[7] != ''){

        end(3,5,7);
    }
else if(squares[1] == squares[5]
    && squares[5] == squares[9]
     && squares[9] != ''){

        end(1,5,9);
    }
else if(squares[1] == squares[4]
    && squares[4] == squares[7]
     && squares[7] != ''){

        end(1,4,7);
    }
else if(squares[2] == squares[5]
    && squares[5] == squares[8]
     && squares[8] != ''){

        end(2,5,8);
    }
else if(squares[3] == squares[6]
    && squares[6] == squares[9]
     && squares[9] != ''){

        end(3,6,9);

    }
    //////////------- no winner-///
    /*
    else{
if(squares[1] != squares[2]
    && squares[2] != squares[3]
     && squares[1] != ''){
     theEnd();
}
else if(squares[4] != squares[5]
    && squares[5] != squares[6]
     && squares[6] != ''){
        theEnd();
    }
else if(squares[7] == squares[8]
    && squares[8] == squares[9]
     && squares[9] != ''){
        end(7,8,9);
    }
else if(squares[3] != squares[5]
    && squares[5] != squares[7]
     && squares[7] != ''){
        theEnd();
    }
else if(squares[1] != squares[5]
    && squares[5] != squares[9]
     && squares[9] != ''){
        theEnd();
    }
else if(squares[1] != squares[4]
    && squares[4] != squares[7]
     && squares[7] != ''){
        theEnd();
    }
else if(squares[2] != squares[5]
    && squares[5] != squares[8]
     && squares[8] != ''){
        theEnd();
    }
else if(squares[3] != squares[6]
    && squares[6] != squares[9]
     && squares[9] != ''){
        theEnd();

    }
}*/

}

function game(id) {
    let element = document.getElementById(id)
    if (turn === 'x' && element.innerHTML =='') {
        element.innerHTML = 'x';
        turn ='o';
        title.innerHTML = 'o';
    }
    else if(turn === 'o' && element.innerHTML ==''){
        element.innerHTML = 'o';
        turn ='x';
        title.innerHTML = 'x';

    }
    winner();
}
